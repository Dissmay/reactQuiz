const Auxiliary = props => props.children

export default Auxiliary